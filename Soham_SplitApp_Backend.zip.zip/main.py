from fastapi import FastAPI
from fastapi.responses import RedirectResponse
from routes.expenses import router as expense_router

app = FastAPI()
app.include_router(expense_router)

# 🔁 Redirect base URL ("/") to Swagger docs ("/docs")
@app.get("/", include_in_schema=False)
def redirect_to_docs():
    return RedirectResponse(url="/docs")
