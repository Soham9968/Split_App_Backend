from typing import List, Optional
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from database import expenses_collection
from bson.objectid import ObjectId
from bson.json_util import dumps, loads
from fastapi import Body


router = APIRouter()


class Expense(BaseModel):
    amount: float
    description: str
    paid_by: str
    participants: Optional[List[str]] = []
    split_type: Optional[str] = "equal"  # options: percentage, exact
    shares: Optional[dict] = None



@router.get("/expenses")
def list_expenses():
    expenses = []
    for exp in expenses_collection.find():
        exp["_id"] = str(exp["_id"])
        expenses.append(exp)
    return {"success": True, "data": expenses}


@router.post("/expenses")
def add_expense(expense: Expense = Body(...)):
    try:
        # Convert to dictionary and remove fields that are None
        data = expense.dict(exclude_none=True)

        # Insert into MongoDB
        result = expenses_collection.insert_one(data)

        # Add the generated _id to response data
        data["_id"] = str(result.inserted_id)

        # ✅ Print to PyCharm terminal
        print("✅ Inserted ID:", data["_id"])

        return {
            "success": True,
            "message": "Expense added successfully",
            "data": data
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.delete("/expenses/{expense_id}")
def delete_expense(expense_id: str):
    try:
        result = expenses_collection.delete_one({"_id": ObjectId(expense_id)})
        if result.deleted_count == 0:
            raise HTTPException(status_code=404, detail="Expense not found")
        return {"success": True, "message": "Expense deleted successfully"}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
@router.get("/people")
def list_people():
    people = set()

    for exp in expenses_collection.find():
        people.add(exp.get("paid_by", ""))
        for p in exp.get("participants", []):
            people.add(p)

    people = list(filter(None, people))  # remove empty strings
    return {"success": True, "data": sorted(people)}

@router.get("/balances")
def get_balances():
    from decimal import Decimal, ROUND_HALF_UP

    balances = {}

    for exp in expenses_collection.find():
        amount = Decimal(str(exp["amount"]))
        participants = exp.get("participants", [])
        paid_by = exp["paid_by"]
        share = (amount / Decimal(len(participants))) if participants else Decimal(0)

        # Add amount paid
        balances[paid_by] = balances.get(paid_by, Decimal(0)) + amount

        # Subtract owed share
        for person in participants:
            balances[person] = balances.get(person, Decimal(0)) - share

    # Round all balances cleanly to 2 decimal places
    final_balances = {}
    for person, bal in balances.items():
        rounded = bal.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        if rounded != Decimal("0.00"):
            final_balances[person] = float(rounded)

    return {
        "success": True,
        "data": final_balances
    }


@router.get("/settlements")
def get_settlements():
    from decimal import Decimal, ROUND_HALF_UP

    balances = {}

    for exp in expenses_collection.find():
        amount = Decimal(str(exp["amount"]))
        participants = exp.get("participants", [])
        paid_by = exp["paid_by"]
        share = (amount / Decimal(len(participants))) if participants else Decimal(0)

        balances[paid_by] = balances.get(paid_by, Decimal(0)) + amount
        for person in participants:
            balances[person] = balances.get(person, Decimal(0)) - share

    creditors = [(p, b) for p, b in balances.items() if b > Decimal("0.005")]
    debtors = [(p, b) for p, b in balances.items() if b < Decimal("-0.005")]

    creditors.sort(key=lambda x: x[1], reverse=True)
    debtors.sort(key=lambda x: x[1])

    settlements = []
    i = j = 0

    while i < len(debtors) and j < len(creditors):
        debtor, d_amt = debtors[i]
        creditor, c_amt = creditors[j]

        payment = min(-d_amt, c_amt)
        payment = payment.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)

        settlements.append({
            "from": debtor,
            "to": creditor,
            "amount": float(payment)
        })

        debtors[i] = (debtor, d_amt + payment)
        creditors[j] = (creditor, c_amt - payment)

        if abs(debtors[i][1]) < Decimal("0.005"):
            i += 1
        if abs(creditors[j][1]) < Decimal("0.005"):
            j += 1

    return {
        "success": True,
        "data": settlements
    }
