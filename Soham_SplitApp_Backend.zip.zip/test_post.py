import requests

url = "http://127.0.0.1:8000/expenses"
data = {
    "amount": 500,
    "description": "Dinner at BBQ Nation",
    "paid_by": "Shantanu",
    "participants": ["Shantanu", "Sanket", "Om"],
    "split_type": "equal",
    "shares": None
}

headers = {"Content-Type": "application/json"}

response = requests.post(url, json=data, headers=headers)

print("Status Code:", response.status_code)
print("Response JSON:", response.text)
